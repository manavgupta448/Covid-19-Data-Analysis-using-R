rm(list=ls()) # removes all variables stored previously
install.packages("Hmisc")

library(Hmisc) # import

data <- read.csv("C:/Users/manav/Downloads/COVID19_line_list_data.csv")
describe(data) # Hmisc command

data <- data[!duplicated(data), ]


# cleaned up death column
data$death_dummy <- as.integer(data$death != 0)




# death rate
sum(data$death_dummy) / nrow(data)



#summary for all variables
summary(data)
sapply(data[sapply(data, is.numeric)], function(x) c(mean = mean(x, na.rm = TRUE), 
                                                     sd = sd(x, na.rm = TRUE)))


# AGE
# claim: people who die are older
dead = subset(data, death_dummy == 1)
alive = subset(data, death_dummy == 0)
mean(dead$age, na.rm = TRUE)
mean(alive$age, na.rm = TRUE)



# is this statistically significant?
t.test(alive$age, dead$age, alternative="two.sided", conf.level = 0.99)


# normally, if p-value < 0.05, we reject null hypothesis
# here, p-value ~ 0, so we reject the null hypothesis and 
# conclude that this is statistically significant

# GENDER

#univariate analysis : categorical variables
ggplot(data, aes(x = gender)) +
  geom_bar(fill = "cyan") +
  labs(title = "Gender Distribution", x = "Gender", y = "Count")

#gender distribution through pie chart
gender_dist <- table(data$gender)
pie(gender_dist, main = "Gender Distribution", col = rainbow(length(gender_dist)))







# claim: gender has no effect
men = subset(data, gender == "male")
women = subset(data, gender == "female")
mean(men$death_dummy, na.rm = TRUE) #8.5%!
mean(women$death_dummy, na.rm = TRUE) #3.7%




# is this statistically significant?
t.test(men$death_dummy, women$death_dummy, alternative="two.sided", conf.level = 0.99)


# 99% confidence: men have from 0.8% to 8.8% higher chance
# of dying.
# p-value = 0.002 < 0.05, so this is statistically
# significant






library(ggplot2)

# age distribution
ggplot(data, aes(x = age)) +
  geom_histogram(binwidth = 5, fill = "blue", color = "white") +
  theme_minimal() +
  labs(title = "Age Distribution", x = "Age", y = "Frequency")




#  recovery rate
data$recovered_dummy <- as.integer(data$recovered == 1)
recovery_rate <- sum(data$recovered_dummy, na.rm = TRUE) / nrow(data)
cat("Recovery Rate:", recovery_rate, "\n")


#age vs death
ggplot(data, aes(x = as.factor(death_dummy), y = age)) +
  geom_boxplot() +
  labs(title = "Age Distribution by Death Status", x = "Death (0=Alive, 1=Dead)", y = "Age")




# correlation analysis
numeric_cols <- sapply(data, is.numeric)
cor_matrix <- cor(data[, numeric_cols], use = "pairwise.complete.obs")
print(cor_matrix)




